public class Mother{
    int x=5;
    public void show(){
        System.out.println(x);
    }
}