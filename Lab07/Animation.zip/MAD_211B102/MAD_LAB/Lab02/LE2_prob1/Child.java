public class Child extends Mother{
    //empty body
}