public class Child extends Mother{
    public void show(){
        System.out.println("In child class");
    }
}