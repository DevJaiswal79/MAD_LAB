public class Mother{
    public void show(){
        System.out.println("In mother class");
    }
}