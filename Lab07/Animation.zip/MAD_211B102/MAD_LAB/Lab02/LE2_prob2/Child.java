public class Child{
    public void show(){
        System.out.println("From child class");
    }
}