public class Mother{
    public void show(){
        System.out.println("From mother class");
    }
}