public class Two extends One{
    public Two(){
        super(6);
    }
}