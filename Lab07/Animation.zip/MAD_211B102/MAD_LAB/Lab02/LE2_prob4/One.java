public class One{
    public One(int x){
        System.out.printf("Inside One : %d",x);
    }
}