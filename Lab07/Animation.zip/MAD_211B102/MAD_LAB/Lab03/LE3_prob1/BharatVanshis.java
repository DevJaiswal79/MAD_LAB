public abstract class BharatVanshis{
    public void fight(){
     System.out.println("BharatVanshis are fighter's");   
    }
    public abstract void obey();
    public abstract void kind();
}