public class Pandavs extends BharatVanshis{
    public void obey(){
        System.out.println("pandavs were obeydient");
    }
    public void kind(){
        System.out.println("pandavs were kind");
    }
}