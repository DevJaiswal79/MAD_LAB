public class Vikarn extends Kauravs{
    public void kind(){
        System.out.println("Vikran was  kind");
    }
    public void obey(){
        System.out.println("Vikran was obeydient");
    }
}