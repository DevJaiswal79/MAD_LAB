public class Bheem extends Pandavs{
    public void kind(){
        System.out.println("Bheem was less kind");
    }
}