public class Kauravs extends BharatVanshis{
    public void obey(){
        System.out.println("Kauravs were disobeydient");
    }
    public void kind(){
        System.out.println("Kauravs were creul");
    }
}