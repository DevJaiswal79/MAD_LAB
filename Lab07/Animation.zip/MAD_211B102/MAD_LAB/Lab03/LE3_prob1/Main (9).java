public class Main
{
	public static void main(String[] args) {
	    System.out.println("Arjun:-");
	    Pandavs ref = new Pandavs();
	    ref.fight();
	    ref.kind();
	    ref.obey();
	    System.out.println("Bheem:-");
	    Bheem ref1 = new Bheem();
	    ref1.fight();
	    ref1.kind();
	    ref1.obey();	  
	    System.out.println("Duryodhan:-");
	    Kauravs ref2 = new Kauravs();
	    ref2.fight();
	    ref2.kind();
	    ref2.obey();
	    System.out.println("Vikarn:-");
	    Vikarn ref3 = new Vikarn();
	    ref3.fight(); 
	    ref3.kind();
	    ref3.obey();
	    
	}
}
