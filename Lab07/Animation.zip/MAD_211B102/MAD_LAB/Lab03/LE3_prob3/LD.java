public class LD extends Duck implements Quackable,Flyable{
    public void sound(){
        System.out.println("LD can Quack");
    }
    public void fly(){
        System.out.println("LD can fly");
    }
}