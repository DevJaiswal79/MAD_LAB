public class WD extends Duck{
}