public class RD extends Duck implements Quackable{
    public void sound(){
        System.out.println("RD can squeak");
    }
}