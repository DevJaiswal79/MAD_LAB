interface Quackable{
    void sound();
}