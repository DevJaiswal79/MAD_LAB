public abstract class Duck{
    void swim(){
        System.out.println("can swim");
    }
}