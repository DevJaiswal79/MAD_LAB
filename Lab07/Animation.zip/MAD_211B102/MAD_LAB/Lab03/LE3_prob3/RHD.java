public class RHD extends Duck implements Quackable, Flyable{
    public void sound(){
        System.out.println("RHD can Quack");
    }
    public void fly(){
        System.out.println("RHD can fly");
    }
}