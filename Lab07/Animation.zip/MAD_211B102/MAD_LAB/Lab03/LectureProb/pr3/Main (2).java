public class Main
{
	public static void main(String[] args) {
		    Test t1 = new Test();
	        t1.display();
	        t1.show();
	}
}
