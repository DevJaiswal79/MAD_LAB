interface C extends A , B {

}