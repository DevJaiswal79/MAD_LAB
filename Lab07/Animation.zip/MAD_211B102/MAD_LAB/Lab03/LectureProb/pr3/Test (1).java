class Test implements C{
    public void show(){
        System.out.println("Comming from interface A");
    }
    public void display(){
        System.out.println("Comming from interface B");
    }
}