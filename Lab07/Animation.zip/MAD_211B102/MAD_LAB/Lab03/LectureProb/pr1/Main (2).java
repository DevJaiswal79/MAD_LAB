public class Main
{
	public static void main(String[] args) {
		    C t1 = new C();
	        t1.show();
	        t1.display();
	}
}
