public class B{
    void display(){
        System.out.println("Inside class B display");
    }
}