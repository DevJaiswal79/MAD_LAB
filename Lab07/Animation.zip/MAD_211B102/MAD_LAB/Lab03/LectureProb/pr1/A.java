interface A{
    void show();
}