class C extends B implements A{
    public void show(){
        System.out.println("Comming from interface");
    }
}