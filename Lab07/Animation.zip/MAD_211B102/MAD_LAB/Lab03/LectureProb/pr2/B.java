interface B{
    void display();
}