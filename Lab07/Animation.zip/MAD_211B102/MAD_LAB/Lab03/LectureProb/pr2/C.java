class C implements A ,  B {
    public void show(){
        System.out.println("Comming from interface A");
    }
    public void display(){
        System.out.println("Comming from interface B");
    }
}