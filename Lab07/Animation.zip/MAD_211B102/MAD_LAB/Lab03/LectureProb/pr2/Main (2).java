public class Main
{
	public static void main(String[] args) {
		    C t1 = new C();
	        t1.display();
	        t1.show();
	}
}
